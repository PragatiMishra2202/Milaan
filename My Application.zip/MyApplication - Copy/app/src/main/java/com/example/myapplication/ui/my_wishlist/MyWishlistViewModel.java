package com.example.myapplication.ui.my_wishlist;

import androidx.lifecycle.ViewModel;

public class MyWishlistViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
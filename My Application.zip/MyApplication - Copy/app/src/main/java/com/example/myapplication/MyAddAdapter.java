package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class MyAddAdapter  extends RecyclerView.Adapter<MyAddAdapter.ViewHolder>{

        List<PromoteAdData> mListName;
        private Context context;

private static final String TAG="ShopAdapter";

    /**
     * setup Constructure
    */
    public MyAddAdapter(List<PromoteAdData> mListName,Context context){
        this.mListName=mListName;
        this.context=context;
        }

     @Override
     public MyAddAdapter.ViewHolder onCreateViewHolder(ViewGroup parent,int viewType){
        LayoutInflater inflater=LayoutInflater.from(parent.getContext());
        View v=inflater.inflate(R.layout.show_ad_items_adapter,parent,false);
        return new MyAddAdapter.ViewHolder(v);
        }

        @Override
        public void onBindViewHolder(MyAddAdapter.ViewHolder holder,int position) {

            PromoteAdData myAddDataList=mListName.get(position);



            holder.registrationNumber.setText(myAddDataList.getmName());

            holder.modelNumber.setText(myAddDataList.getmBrandName());

            holder.distanceTrvl.setText(myAddDataList.getmOriginalPrice()+"");

            holder.itemPrice.setText(myAddDataList.getmPrice()+"");

            holder.registrationState.setText(myAddDataList.getmDuration());

            holder.brandName.setText(myAddDataList.getmBrandName());

            holder.descProduct.setText(myAddDataList.getmDesc());

            Glide.with(context)
                    .load(myAddDataList.getmImageUrl())
                    .into(holder.image_upload);

        }
        @Override
        public int getItemCount(){
         return mListName.size();

           }


/**
 * bind ViewHolder
 */
public class ViewHolder extends RecyclerView.ViewHolder {

    private ImageView image_upload;
    private TextView registrationNumber,modelNumber,distanceTrvl,itemPrice,registrationState,brandName,descProduct;


    public ViewHolder(View itemView) {
        super(itemView);

        image_upload=itemView.findViewById(R.id.image_upload);

        registrationNumber=itemView.findViewById(R.id.registrationNumber);

        modelNumber=itemView.findViewById(R.id.modelNumber);

        distanceTrvl=itemView.findViewById(R.id.distanceTrvl);

        itemPrice=itemView.findViewById(R.id.itemPrice);

        registrationState=itemView.findViewById(R.id.registrationState);

        brandName=itemView.findViewById(R.id.brandName);

        descProduct=itemView.findViewById(R.id.descProduct);

    }

  }
}
package com.example.myapplication.ui.my_ads;

import androidx.lifecycle.ViewModel;

public class MyAdsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
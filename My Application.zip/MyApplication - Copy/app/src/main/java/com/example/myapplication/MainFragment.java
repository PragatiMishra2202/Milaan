package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;


public class MainFragment extends Fragment {

   public MainFragment(){

   }

   private RecyclerView categoryRecyclerView;
   private category_adapter categoryAdapter;
   private RecyclerView testing;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_main, container, false);
        categoryRecyclerView = view.findViewById(R.id.category_recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        categoryRecyclerView.setLayoutManager(layoutManager);

        List<category_model> category_modelList = new ArrayList<category_model>();
        category_modelList.add(new category_model("link","Home"));
        category_modelList.add(new category_model("link","Cars"));
        category_modelList.add(new category_model("link","Properties"));
        category_modelList.add(new category_model("link","Mobiles"));
        category_modelList.add(new category_model("link","Bikes"));
        category_modelList.add(new category_model("link","Electronics & Appliances"));
        category_modelList.add(new category_model("link","Furniture"));
        category_modelList.add(new category_model("link","Fashion"));
        category_modelList.add(new category_model("link","Jobs"));
        category_modelList.add(new category_model("link","Books, Sports & Hobbies"));

        categoryAdapter = new category_adapter(category_modelList);
        categoryRecyclerView.setAdapter(categoryAdapter);
        categoryAdapter.notifyDataSetChanged();

        List<SliderModel> sliderModelList = new ArrayList<>();

        sliderModelList = new ArrayList<SliderModel>();
        sliderModelList.add(new SliderModel(R.drawable.banner3,"#077AE4"));
        sliderModelList.add(new SliderModel(R.drawable.banner4,"#077AE4"));
        sliderModelList.add(new SliderModel(R.drawable.banner9,"#077AE4"));

        sliderModelList.add(new SliderModel(R.drawable.banner10,"#077AE4"));
        sliderModelList.add(new SliderModel(R.drawable.banner11,"#077AE4"));
        sliderModelList.add(new SliderModel(R.drawable.banner12,"#077AE4"));
        sliderModelList.add(new SliderModel(R.drawable.banner1,"#077AE4"));
        sliderModelList.add(new SliderModel(R.drawable.banner2,"#077AE4"));
        sliderModelList.add(new SliderModel(R.drawable.banner3,"#077AE4"));

        sliderModelList.add(new SliderModel(R.drawable.banner4,"#077AE4"));
        sliderModelList.add(new SliderModel(R.drawable.banner9,"#077AE4"));
        sliderModelList.add(new SliderModel(R.drawable.banner10,"#077AE4"));


        List<HorizontalProductScrollModel> horizontalProductScrollModelList = new ArrayList<>();
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.stripad1, "ABC", "PQR", "XYZ"));
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.stripad1, "ABC", "PQR", "XYZ"));
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.stripad1, "ABC", "PQR", "XYZ"));
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.stripad1, "ABC", "PQR", "XYZ"));
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.stripad1, "ABC", "PQR", "XYZ"));
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.stripad1, "ABC", "PQR", "XYZ"));
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.stripad1, "ABC", "PQR", "XYZ"));
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.stripad1, "ABC", "PQR", "XYZ"));
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.stripad1, "ABC", "PQR", "XYZ"));

        testing = view.findViewById(R.id.main_page_recycler_view);
        LinearLayoutManager testingLayoutManager = new LinearLayoutManager(getContext());
        testingLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        testing.setLayoutManager(testingLayoutManager);

        List<MainPageModel> mainPageModelList = new ArrayList<>();
        mainPageModelList.add(new MainPageModel(0, sliderModelList));
        mainPageModelList.add(new MainPageModel(1,R.drawable.stripad2,"#077AE4"));
        mainPageModelList.add(new MainPageModel(2,"Deals of the Day",horizontalProductScrollModelList));
        mainPageModelList.add(new MainPageModel(3,"Recommended",horizontalProductScrollModelList));

        MainPageAdapter adapter = new MainPageAdapter(mainPageModelList);
        testing.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        return view;
    }
}

package com.example.myapplication;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceManger {

    public static final String USER_PREFS = "user_prefs";
    public static final String PREF_KEY_FCM_TOKEN = "fcm_token";


    private static SharedPreferences preferences;

    public PreferenceManger() {
    }

    private static synchronized SharedPreferences getInstance() {
        if (preferences == null) {
            preferences = ClearAppApplication.getmInstance().getSharedPreferences(USER_PREFS, Context.MODE_PRIVATE);
        }
        return preferences;
    }

    private SharedPreferences.Editor getEditor() {
        return getInstance().edit();
    }




    public void putString(String key, String value) {
        SharedPreferences.Editor editor = getEditor();
        editor.putString(key, value);
        editor.apply();
    }


    public void putInt(String key, int value) {
        SharedPreferences.Editor editor = getEditor();
        editor.putInt(key, value);
        editor.apply();
    }

    public String getStringValue(String key) {
        return getInstance().getString(key, "");
    }

    public int getIntegerValue(String key) {
        return getInstance().getInt(key, 0);
    }


}

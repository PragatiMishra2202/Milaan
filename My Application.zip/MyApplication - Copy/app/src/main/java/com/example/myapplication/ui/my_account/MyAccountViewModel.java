package com.example.myapplication.ui.my_account;

import androidx.lifecycle.ViewModel;

public class MyAccountViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomappbar.BottomAppBar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CategoryActivity extends AppCompatActivity implements View.OnClickListener {

    private GridLayout categoryGridView;
    private CardView cv_cars;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        String title = getIntent().getStringExtra("CategoryName");
    //    toolbar.setTitle(title);
         getSupportActionBar().setTitle(title);
         getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        categoryGridView = findViewById(R.id.category_grid_layout);

        cv_cars=findViewById(R.id.cv_cars);
        cv_cars.setOnClickListener(this);

        //List<SliderModel> sliderModelList = new ArrayList<>();

        /*sliderModelList = new ArrayList<SliderModel>();
        sliderModelList.add(new SliderModel(R.mipmap.ic_launcher_round,"#000000"));
        sliderModelList.add(new SliderModel(R.mipmap.profile_placeholder_,"#000000"));
        sliderModelList.add(new SliderModel(R.mipmap.logomilaanc,"#000000"));

        sliderModelList.add(new SliderModel(R.mipmap.ic_launcher,"#000000"));
        sliderModelList.add(new SliderModel(R.mipmap.ic_launcher_round,"#000000"));
        sliderModelList.add(new SliderModel(R.mipmap.profile_placeholder_,"#000000"));
        sliderModelList.add(new SliderModel(R.mipmap.logomilaanc,"#000000"));
        sliderModelList.add(new SliderModel(R.mipmap.ic_launcher,"#000000"));
        sliderModelList.add(new SliderModel(R.mipmap.ic_launcher_round,"#000000"));

        sliderModelList.add(new SliderModel(R.mipmap.profile_placeholder_,"#000000"));
        sliderModelList.add(new SliderModel(R.mipmap.logomilaanc,"#000000"));
        sliderModelList.add(new SliderModel(R.mipmap.ic_launcher,"#000000"));


        List<HorizontalProductScrollModel> horizontalProductScrollModelList = new ArrayList<>();
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.arrow, "ABC", "PQR", "XYZ"));
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.arrow, "ABC", "PQR", "XYZ"));
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.arrow, "ABC", "PQR", "XYZ"));
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.arrow, "ABC", "PQR", "XYZ"));
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.arrow, "ABC", "PQR", "XYZ"));
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.arrow, "ABC", "PQR", "XYZ"));
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.arrow, "ABC", "PQR", "XYZ"));
        horizontalProductScrollModelList.add(new HorizontalProductScrollModel(R.drawable.arrow, "ABC", "PQR", "XYZ"));


        LinearLayoutManager testingLayoutManager = new LinearLayoutManager(this);
        testingLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        categoryRecyclerView.setLayoutManager(testingLayoutManager);

        List<MainPageModel> mainPageModelList = new ArrayList<>();
        mainPageModelList.add(new MainPageModel(0, sliderModelList));
        mainPageModelList.add(new MainPageModel(1,R.drawable.my_wishlist,"#000000"));
        mainPageModelList.add(new MainPageModel(2,"Deals of the Day",horizontalProductScrollModelList));
        mainPageModelList.add(new MainPageModel(3,"Categories",horizontalProductScrollModelList));

        MainPageAdapter adapter = new MainPageAdapter(mainPageModelList);
        categoryRecyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();*/


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.search_icon, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_search) {

            return true;
        }
        else if (id == android.R.id.home){
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.cv_cars:

                startActivity(new Intent(CategoryActivity.this,PromoteAdActivity.class));

                break;
        }
    }
}
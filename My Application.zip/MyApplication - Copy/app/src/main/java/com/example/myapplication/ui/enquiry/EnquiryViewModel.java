package com.example.myapplication.ui.enquiry;

import androidx.lifecycle.ViewModel;

public class EnquiryViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}